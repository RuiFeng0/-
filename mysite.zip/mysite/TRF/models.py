# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class web(models.Model):
    title = models.CharField(max_length = 150,default='标题')
    name=models.CharField(max_length=30,default='姓名')
    num = models.CharField(max_length = 50,default='工号')
    apr = models.CharField(max_length = 50,default='部门')
    aprnum = models.CharField(max_length = 50,default='部门编号')
    body = models.TextField(default='内容')
    timestamp = models.DateTimeField(null=True)

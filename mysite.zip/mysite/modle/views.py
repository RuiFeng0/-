from django.shortcuts import render

# Create your views here.

def login(request):
    return render (request,'login.html')

def index(request):
        return render(request, 'index.html')

def mail(request):
    return render (request,'mail.html')

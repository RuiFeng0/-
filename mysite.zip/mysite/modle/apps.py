from django.apps import AppConfig


class ModleConfig(AppConfig):
    name = 'modle'

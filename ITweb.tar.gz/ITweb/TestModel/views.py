from django.shortcuts import render
from .import sqlmain

# Create your views here.
def login(request):
    return render (request,'login.html')

def index(request):
    return render(request, 'layuimodel.html')

def layuimodel2(request):
    return render(request,'layuimodel2.html')

def layuimodel3(request):
    return render(request,'layuimodel3.html')

def layuimodel4(request):
    return render(request,'layuimodel4.html')

def layuimodel5(request):
    return render(request,'layuimodel5.hmtl')

def layuimodel6(request):
    return render(request,'layuimodel6.html')

def layuimodel7(request):
    return render(request,'layuimodel7.html')

def layuimodel8(request):
    return render(request,'layuimodel8.html')

def layuimodel9(request):
    return render(request,'layuimodel9.html')

def layuimodel10(request):
    return render(request,'layuimodel10.html')
#
# def sqlCentence():
#     return sqlmain.iselect()

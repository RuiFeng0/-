from django.conf.urls import url
from django.contrib import admin
from .import views



urlpatterns = [
    url(r'^$',views.login),
    url(r'^index',views.index),
    url(r'^layuimodel2',views.layuimodel2),
    url(r'^layuimodel3',views.layuimodel3),
    url(r'^layuimodel4',views.layuimodel4),
    url(r'^layuimodel5',views.layuimodel5),
    url(r'^layuimodel6',views.layuimodel6),
    url(r'^layuimodel7',views.layuimodel7),
    url(r'^layuimodel8',views.layuimodel8),
    url(r'^layuimodel9',views.layuimodel9),
    url(r'^layuimodel10',views.layuimodel10),
]

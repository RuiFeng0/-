import pymssql


class Newsql():
    def __init__():
        conn = pymssql.connect(
            '172.17.1.27',    # server    数据库服务器名称或IP
            'DEMO',     # user      用户名
            'UNEECMis',        # password  密码
            'DEMO'      # database  数据库名称
            )

        cursor = conn.cursor()  #創建遊標


    def iselect(表名):
            x = cursor.execute('select * from 表名')
            conn.commit()
            conn.close()
            return x
    def iadd(條件):
            # 新建、插入操作
            x = cursor.execute('條件'
            )
            conn.commit()
            conn.close()
            return x
    def idelect(條件):
            # 刪除操作
            x = cursor.execute('條件'
            )
            conn.commit()
            conn.close()
            return x



    # cursor.executemany(
    #     "INSERT INTO persons VALUES (%d, %s, %s)",
    #     [(1, 'John Smith', 'John Doe'),
    #      (2, 'Jane Doe', 'Joe Dog'),
    #      (3, 'Mike T.', 'Sarah H.')])
    # 如果没有指定autocommit属性为True的话就需要调用commit()方法
    # conn.commit()

    # # 查询操作
    # cursor.execute('SELECT * FROM persons WHERE salesrep=%s', 'John Doe')
    # row = cursor.fetchone()
    # while row:
    #     print("ID=%d, Name=%s" % (row[0], row[1]))
    #     row = cursor.fetchone()

    # 也可以使用for循环来迭代查询结果
    # for row in cursor:
    #     print("ID=%d, Name=%s" % (row[0], row[1]))

    # 关闭连接
    # conn.close()
